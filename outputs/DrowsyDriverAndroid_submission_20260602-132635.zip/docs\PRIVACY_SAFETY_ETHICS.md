# Privacy, Safety, And Ethics

## Why This Matters

The project uses a camera pointed at a driver's face. That makes privacy and
safety considerations part of the technical design, not an optional appendix.

## Privacy Risks

- Face video is sensitive personal data.
- Continuous recording may reveal behavior, location context, and identity.
- If used by an organization, drivers may feel monitored or pressured.
- A false alert can be annoying; a missed alert can be dangerous.

## Mitigations In This Project

| Risk | Mitigation |
|---|---|
| Raw face video exposure | Process frames on-device by default |
| Excessive storage | Store event logs instead of video |
| Lack of transparency | Show visible camera status and alert state |
| False sense of safety | Clearly present the app as a prototype aid |
| Dataset bias | Report dataset limitations and test conditions |

## Recommended Event Log

If logging is implemented, keep it minimal:

```text
timestamp
state
confidence
EAR
MAR
FPS
device_id or anonymous session_id
```

Avoid by default:

- full video;
- face screenshots;
- GPS;
- audio recording;
- identity information.

## Report Wording

Use this paragraph in the limitations or future-work section:

> Vì hệ thống sử dụng camera hướng vào khuôn mặt tài xế, nhóm ưu tiên xử lý
> trực tiếp trên thiết bị và không lưu video khuôn mặt mặc định. Nếu triển khai
> trong tổ chức, hệ thống cần có thông báo rõ ràng, sự đồng ý của người dùng,
> chính sách lưu trữ dữ liệu và chỉ nên lưu log sự kiện tối thiểu thay vì video
> liên tục.

## Safety Wording

Use this paragraph when presenting:

> Hệ thống chỉ là công cụ hỗ trợ cảnh báo sớm, không thay thế trách nhiệm nghỉ
> ngơi của tài xế và không phải hệ thống an toàn đã được chứng nhận cho xe
> thương mại. Trước khi dùng thực tế cần kiểm thử có kiểm soát trong nhiều điều
> kiện ánh sáng, góc camera và nhóm người dùng khác nhau.

## Ethical Position

The project should be framed as:

- assistive, not punitive;
- privacy-preserving by default;
- transparent about limitations;
- evaluated with safety-oriented metrics;
- designed to reduce harm, not to surveil drivers continuously.
